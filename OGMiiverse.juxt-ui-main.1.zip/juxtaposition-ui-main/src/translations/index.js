module.exports = {
    JA: require('./ja.json'),
    EN: require('./en.json'),
    FR: require('./fr.json'),
    DE: require('./de.json'),
    IT: require('./it.json'),
    ES: require('./es.json'),
    ZH: require('./zh.json'),
    KO: require('./ko.json'),
    NL: require('./nl.json'),
    PT: require('./pt.json'),
    RU: require('./ru.json'),

};